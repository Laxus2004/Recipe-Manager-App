package com.example.recipemanagerapp

// RecipeModels.kt

enum class Flavor {
    SWEET,
    SAVORY
}

// Data class for a single recipe
data class Recipe(
    val title: String,
    val description: String,
    val flavor: Flavor
)

// Sealed class to represent the different item types in the RecyclerView list
// This allows the list to contain both headers and recipes.
sealed class RecipeListItem {
    data class FlavorTitle(val title: String) : RecipeListItem()
    data class RecipeItem(val recipe: Recipe) : RecipeListItem()
}