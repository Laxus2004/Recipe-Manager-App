package com.example.recipemanagerapp

// RecipeAdapter.kt

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

// Define constants for view types
private const val VIEW_TYPE_TITLE = 0
private const val VIEW_TYPE_RECIPE = 1

class RecipeAdapter(
    private val onItemClicked: (Recipe) -> Unit // Click listener lambda for recipes
) : ListAdapter<RecipeListItem, RecyclerView.ViewHolder>(RecipeDiffCallback()) {

    override fun getItemViewType(position: Int): Int {
        return when (getItem(position)) {
            is RecipeListItem.FlavorTitle -> VIEW_TYPE_TITLE
            is RecipeListItem.RecipeItem -> VIEW_TYPE_RECIPE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            VIEW_TYPE_TITLE -> {
                val view = inflater.inflate(R.layout.item_flavor_title, parent, false)
                FlavorTitleViewHolder(view)
            }
            VIEW_TYPE_RECIPE -> {
                val view = inflater.inflate(R.layout.item_recipe, parent, false)
                RecipeViewHolder(view, onItemClicked)
            }
            else -> throw IllegalArgumentException("Invalid view type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is FlavorTitleViewHolder -> holder.bind(getItem(position) as RecipeListItem.FlavorTitle)
            is RecipeViewHolder -> holder.bind(getItem(position) as RecipeListItem.RecipeItem)
        }
    }

    // --- View Holders ---

    class FlavorTitleViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titleTextView: TextView = itemView.findViewById(R.id.tv_flavor_title)
        fun bind(item: RecipeListItem.FlavorTitle) {
            titleTextView.text = item.title
        }
    }

    class RecipeViewHolder(itemView: View, onItemClicked: (Recipe) -> Unit) : RecyclerView.ViewHolder(itemView) {
        private val titleTextView: TextView = itemView.findViewById(R.id.tv_recipe_title)
        private var currentRecipe: Recipe? = null

        init {
            itemView.setOnClickListener {
                currentRecipe?.let(onItemClicked) // Execute the click lambda with the current recipe
            }
        }

        fun bind(item: RecipeListItem.RecipeItem) {
            currentRecipe = item.recipe
            titleTextView.text = item.recipe.title
        }
    }

    // --- DiffUtil Callback for efficient updates ---

    class RecipeDiffCallback : DiffUtil.ItemCallback<RecipeListItem>() {
        override fun areItemsTheSame(oldItem: RecipeListItem, newItem: RecipeListItem): Boolean {
            return when {
                oldItem is RecipeListItem.FlavorTitle && newItem is RecipeListItem.FlavorTitle ->
                    oldItem.title == newItem.title
                oldItem is RecipeListItem.RecipeItem && newItem is RecipeListItem.RecipeItem ->
                    // Assume title is unique enough for this lab
                    oldItem.recipe.title == newItem.recipe.title
                else -> false
            }
        }

        override fun areContentsTheSame(oldItem: RecipeListItem, newItem: RecipeListItem): Boolean {
            return oldItem == newItem
        }
    }
}