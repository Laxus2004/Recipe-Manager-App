package com.example.recipemanagerapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: RecipeAdapter
    // Separate lists to maintain grouping order
    private val sweetRecipes = mutableListOf<Recipe>()
    private val savoryRecipes = mutableListOf<Recipe>()

    // View variables defined for lateinit initialization
    private lateinit var etTitle: EditText
    private lateinit
    var etDescription: EditText
    private lateinit var btnSweet: Button
    private lateinit var btnSavory: Button
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize Views using findViewById (Step 3)
        etTitle = findViewById(R.id.et_title)
        etDescription = findViewById(R.id.et_description)
        btnSweet = findViewById(R.id.btn_add_sweet)
        btnSavory = findViewById(R.id.btn_add_savory)
        recyclerView = findViewById(R.id.recycler_view_recipes)

        // Setup Adapter and RecyclerView (Step 7)
        // Pass a reference to the dialog function (Step 8)
        adapter = RecipeAdapter(onItemClicked = ::showRecipeDescriptionDialog)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        // Optional: Add a simple divider between items
        recyclerView.addItemDecoration(DividerItemDecoration(this, LinearLayoutManager.VERTICAL))

        // Initial data load (Step 9)
        updateRecipeList()

        // Setup Click Listeners (Step 9)
        btnSweet.setOnClickListener { addRecipe(Flavor.SWEET) }
        btnSavory.setOnClickListener { addRecipe(Flavor.SAVORY) }

        // Setup Swipe-to-Delete (Step 10)
        setupSwipeToDelete()
    }

    /**
     * Helper function to add a new recipe based on the input fields. (Step 9)
     */
    private fun addRecipe(flavor: Flavor) {
        val title = etTitle.text.toString().trim()
        val description = etDescription.text.toString().trim()

        if (title.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Please enter both title and description.", Toast.LENGTH_SHORT).show()
            return
        }

        val newRecipe = Recipe(title, description, flavor)
        when (flavor) {
            Flavor.SWEET -> sweetRecipes.add(newRecipe)
            Flavor.SAVORY -> savoryRecipes.add(newRecipe)
        }

        // Clear the form (Step 9)
        etTitle.setText("")
        etDescription.setText("")

        // Update the RecyclerView list
        updateRecipeList()
        Toast.makeText(this, "${flavor.name} recipe added: $title", Toast.LENGTH_SHORT).show()
    }

    /**
     * Groups the recipes, adds flavor titles, and submits the list to the adapter. (Step 9)
     */
    private fun updateRecipeList() {
        val newList = mutableListOf<RecipeListItem>()

        if (sweetRecipes.isNotEmpty()) {
            newList.add(RecipeListItem.FlavorTitle("Sweet Recipes (${sweetRecipes.size})"))
            // Reverse order so the newest additions appear first in the group
            newList.addAll(sweetRecipes.reversed().map { RecipeListItem.RecipeItem(it) })
        }

        if (savoryRecipes.isNotEmpty()) {
            newList.add(RecipeListItem.FlavorTitle("Savory Recipes (${savoryRecipes.size})"))
            newList.addAll(savoryRecipes.reversed().map { RecipeListItem.RecipeItem(it) })
        }

        // Submit the new grouped list to the ListAdapter
        adapter.submitList(newList)
    }

    /**
     * Shows a dialog with the recipe's description. (Step 8)
     */
    private fun showRecipeDescriptionDialog(recipe: Recipe) {
        AlertDialog.Builder(this)
            .setTitle(recipe.title)
            .setMessage(recipe.description)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    /**
     * Implements ItemTouchHelper for enhanced swipe-to-delete functionality. (Step 10)
     * Uses the custom SwipeToDeleteCallback for visual feedback.
     */
    private fun setupSwipeToDelete() {
        // Create an instance of the custom callback
        val swipeHandler = object : SwipeToDeleteCallback(this) {
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.bindingAdapterPosition
                val item = adapter.currentList.getOrNull(position)

                if (item is RecipeListItem.RecipeItem) {
                    removeRecipe(item.recipe) // Call the removal logic
                }
                // If it's a title, the getMovementFlags in SwipeToDeleteCallback will prevent the swipe.
            }
        }

        val itemTouchHelper = ItemTouchHelper(swipeHandler)
        itemTouchHelper.attachToRecyclerView(recyclerView)
    }

    /**
     * Removes a recipe from the appropriate flavor list and updates the RecyclerView.
     */
    private fun removeRecipe(recipe: Recipe) {
        val wasRemoved = when (recipe.flavor) {
            Flavor.SWEET -> sweetRecipes.remove(recipe)
            Flavor.SAVORY -> savoryRecipes.remove(recipe)
        }

        if (wasRemoved) {
            updateRecipeList()
            Toast.makeText(this, "${recipe.title} removed.", Toast.LENGTH_SHORT).show()
        }
    }
}
